mex gradientMex.cpp;
mex convConst.cpp;
mex edgesNmsMex.cpp